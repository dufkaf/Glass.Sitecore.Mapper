﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glass.Sitecore.Mapper.Dashboard
{
    public class DashboardGlobals
    {
        public const string TemplateUrl = "/sitecore/shell/Applications/Content%20Manager/default.aspx?he=Template+Manager&pa=0&mo=templateworkspace&ic=Software%2f16x16%2fcomponents.png&ro=%7b3C1715FE-6A13-4FCF-845F-DE308BA9741D%7d&fo=%7b{0}%7d&il";
    }
}
