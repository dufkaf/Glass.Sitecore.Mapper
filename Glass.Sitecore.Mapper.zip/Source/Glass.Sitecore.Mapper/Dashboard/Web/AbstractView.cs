﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Glass.Sitecore.Mapper.Dashboard.Web
{
    public abstract class AbstractView
    {
        public abstract void Response(HttpResponse response);


    }
}
