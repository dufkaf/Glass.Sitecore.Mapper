﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Glass.Sitecore.Mapper.Tests
{
    [TestFixture]
    public class SitecoreContextFixture
    {

        #region Method - QuerySingleRelative

        #endregion
    }
}
