﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Glass.Sitecore.Mapper.Tests.Dynamic
{
    public static class DynamicExtensions
    {
        //public static IEnumerable<dynamic> Where(this IEnumerable<dynamic> targets, Func<dynamic, bool> predicate)
        //{
        //    List<dynamic> results = new List<dynamic>();
        //    foreach (var target in targets)
        //    {
        //        if (predicate.Invoke(target))
        //            results.Add(target);
        //    }
        //    return results;
            
        //}

        //public static IEnumerable<dynamic> AsQueryable(this dynamic target)
        //{
        //    return target as IEnumerable<dynamic>;
        //}
    }
}
